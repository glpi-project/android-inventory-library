package org.flyve.inventory;


import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {


}
